Legacy path replaced. See .ai/retrieval/endpoints/endpoint-contract-analysis.md
