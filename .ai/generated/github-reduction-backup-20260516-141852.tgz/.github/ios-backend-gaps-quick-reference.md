Legacy path replaced. See .ai/retrieval/gaps/ios-backend-gaps-quick-reference.md
