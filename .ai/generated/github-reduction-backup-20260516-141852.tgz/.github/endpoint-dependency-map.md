Legacy path replaced. See .ai/retrieval/endpoints/endpoint-dependency-map.md
