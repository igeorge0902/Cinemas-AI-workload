Legacy path replaced. Instructions now live in .ai/retrieval/instructions.md
