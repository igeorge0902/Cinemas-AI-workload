Legacy path replaced. See .ai/retrieval/endpoints/endpoint-analysis-EXECUTIVE-SUMMARY.md
