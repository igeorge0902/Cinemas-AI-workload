# Extracted Assets (from `icons.png`)

These assets were auto-extracted from:
- `.specify/features/SwiftUIFeatures/icons.png`

Extraction script:
- `.specify/features/SwiftUIFeatures/extract_icons_from_sheet.py`

Manifest:
- `.specify/features/SwiftUIFeatures/extracted-assets/manifest.json`

## Important

- Mapping is **best effort** (alpha segmentation + layout/OCR hints).
- You must visually verify each icon before using in `Assets.xcassets`.
- Current gap: `required/actions/action_calendar_12` was not confidently separable and still needs explicit source confirmation/provision.

## Folder layout

- `required/navigation/`
- `required/favorite/`
- `required/actions/`
- `required/placeholder/`
- `optional/metadata/`

