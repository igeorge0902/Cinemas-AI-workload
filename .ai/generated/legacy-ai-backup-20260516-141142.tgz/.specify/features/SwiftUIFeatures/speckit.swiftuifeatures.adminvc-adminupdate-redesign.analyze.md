# Speckit Analyze: AdminVC + AdminUpdateVC redesign alignment

## Objective
Align iOS implementation with the approved admin prototypes:
- screening date above capacity fields
- rows/seats side-by-side
- category optional
- stronger admin visual grouping
- popover list style aligned to admin usage (movie posters in admin create, compact `venue > movie` rows in admin update)

## Current code findings

### 1) AdminVC layout order and sizing mismatch
- `Storyboard.storyboard` currently places:
  - `NrOfRows` at y=174 and `NrOfSeats` at y=248 (stacked vertically)
  - `Screening Date` at y=322 (below capacity fields)
- References:
  - `SwiftCinemas/SwiftLoginScreen/Storyboard.storyboard:259-288`
- Required by design:
  - move `Screening Date` above capacity
  - place rows + seats on the same horizontal row

### 2) AdminVC capacity inputs are too narrow for new design
- `NrOfRows` and `NrOfSeats` text fields are fixed at ~51 px widths.
- References:
  - `SwiftCinemas/SwiftLoginScreen/Storyboard.storyboard:265-274`
- Required by design:
  - equal-width half-row fields in one horizontal group

### 3) AdminUpdateVC top and bottom actions are frame-based
- `AdminUpdateVC` uses hardcoded frame buttons in `viewWillAppear`:
  - top `Back` + `Clear`
  - bottom `Save` + `Delete`
- References:
  - `SwiftCinemas/SwiftLoginScreen/AdminUpdateVC.swift:60-92`
- Required by design:
  - keep visual style consistent with shared top navigation button system and safe-area aligned placement

### 4) AdminVC bottom Save action is frame-based
- `AdminVC` top uses shared helper, but Save button is still manually framed.
- References:
  - `SwiftCinemas/SwiftLoginScreen/AdminVC.swift:61-74`
- Required by design:
  - stable bottom action placement and consistent style behavior

### 5) Category already optional in logic, but UI semantics need explicit alignment
- Validation already allows empty category by checking only non-empty invalid values.
- References:
  - `SwiftCinemas/SwiftLoginScreen/AdminVC.swift:209-217`
  - `SwiftCinemas/SwiftLoginScreen/AdminUpdateVC.swift:233-242`
- Required by design:
  - label and task semantics should mark category as optional (no blocking behavior)

### 6) Popover behavior exists but styling/grouping needs polish for admin look
- Admin flows already present `MoviesVC`/`VenuesVC` as popovers (90% width, 50% height, no arrow).
- References:
  - `SwiftCinemas/SwiftLoginScreen/AdminVC.swift:128-179`
  - `SwiftCinemas/SwiftLoginScreen/AdminUpdateVC.swift:146-198`
- Movie list behavior by mode:
  - admin create path can show movie imagery
  - admin update path uses compact `venue > movie` rows
- References:
  - `SwiftCinemas/SwiftLoginScreen/MoviesVC.swift` (admin mode cell paths)
- Venue list behavior:
  - admin list mode with selected-item emphasis
- References:
  - `SwiftCinemas/SwiftLoginScreen/VenuesVC.swift` (admin list rendering path)

### 7) Storyboard maintenance risk in AdminUpdateVC
- Heavy `fixedFrame` usage limits adaptability across devices and conflicts with redesigned grouped layout.
- References:
  - `SwiftCinemas/SwiftLoginScreen/Storyboard.storyboard:445-573`

## Recommended implementation scope

### Must-do
1. Rework AdminVC form order + constraints in storyboard:
   - `Movie/Venue` block
   - `Screening Date`
   - `Rows + Seats` one row
   - `Screen ID + Category`
2. Replace hardcoded action button frames with constraint-based layout in both admin screens.
3. Preserve existing payload keys and segue/action wiring.
4. Keep category optional and update labels/help text to reflect it.
5. Align popover styling in Movies/Venues selection to admin visual language while preserving data behavior.

### Should-do
1. Add reusable section container styling helper for admin cards.
2. Add consistent typography spacing for field groups and section headers.
3. Ensure touch targets remain >=44pt.

## Implementation files
- `SwiftCinemas/SwiftLoginScreen/AdminVC.swift`
- `SwiftCinemas/SwiftLoginScreen/AdminUpdateVC.swift`
- `SwiftCinemas/SwiftLoginScreen/Storyboard.storyboard`
- `SwiftCinemas/SwiftLoginScreen/MoviesVC.swift`
- `SwiftCinemas/SwiftLoginScreen/VenuesVC.swift`

## Out of scope
- backend endpoint contracts
- payload key renaming
- auth/header contracts
- business logic changes in create/update/delete flows

